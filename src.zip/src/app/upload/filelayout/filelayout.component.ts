import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'filelayout',
  templateUrl: './filelayout.component.html',
  styleUrls: ['./filelayout.component.scss']
})
export class FilelayoutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
