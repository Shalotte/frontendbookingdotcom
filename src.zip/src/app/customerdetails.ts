export class Customerdetails {
 
    title: string;
    first_name: string;
    last_name: string;
    telephone: string;
    email_address: string;
    street_address: string;
    city: string;
    country: string;
    zip_code: string;
   
}