import { Component, OnInit } from '@angular/core';
import {User} from '../user';

@Component({
  selector: 'bookingdetails',
  templateUrl: './details.component.html',
  styleUrls: ['./details.component.scss']
})

export class DetailsComponent implements OnInit {
  user: User;

  constructor() { 
  this.user = JSON.parse(localStorage.getItem('user'));
  }

  ngOnInit() {
  }

}
