import { Component, OnInit } from '@angular/core';
import {BsDatepickerConfig} from 'ngx-bootstrap/datepicker';

import { first } from 'rxjs/operators';
import {User} from '../user';

@Component({
  selector: 'app-customer-layout',
  templateUrl: './customer-layout.component.html',
  styleUrls: ['./customer-layout.component.scss']
})
export class CustomerLayoutComponent implements OnInit {
  datePickerConfig: Partial<BsDatepickerConfig>;
  myDateValue: Date;
  user: User;
  

  constructor() {
      this.user = JSON.parse(localStorage.getItem('user'));
      this.datePickerConfig = Object.assign({},{containerClass: 'theme-dark-blue'});
  }

  
  ngOnInit() {
    this.myDateValue = new Date();

  }

  onDateChange(newDate: Date) {
    console.log(newDate);
  }

}



