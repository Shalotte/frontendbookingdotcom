import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-user-property',
  templateUrl: './user-property.component.html',
  styleUrls: ['./user-property.component.scss']
})
export class UserPropertyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
