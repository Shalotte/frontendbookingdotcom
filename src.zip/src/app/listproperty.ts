export class Listproperty {

    id: number;
    property_name: string;
    property_manager_name: string;
    property_manager_contact_details: string;
    property_street_address: string;
    property_city_name: string;
    propety_country_name: string;
    zip_code: string;
    email: string;
    apartment_type: string;
    number_of_bedrooms: string;
    number_of_living_rooms: string;
    number_of_bathrooms: string;
    price_per_night: string;
    internet_available: string;
    free_internet: string;
    parking_available: string;
    language_spoken: string;
    smoking_allowed: string;
    children_accommodated: string;
    spets_allowed: string;
    minimum_stay: string;
    payment_method: string;
    cleaning_fees: string;
    pic: string;

}
