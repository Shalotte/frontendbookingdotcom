import { Component, OnInit } from '@angular/core';
import {Listproperty} from '../listproperty';
import {ListpropertyService} from '../shared_services/listproperty.service';
import {Router} from '@angular/router';
import {User} from '../user';

@Component({
  selector: 'app-listpropertydisplay',
  templateUrl: './listpropertydisplay.component.html',
  styleUrls: ['./listpropertydisplay.component.scss']
})
export class ListpropertydisplayComponent implements OnInit {

//private listproperty = new Listproperty();
private user: User;
id: number;
private properties: Listproperty[];

constructor(private _listpropertyService: ListpropertyService, private _router: Router) {
  this.user = JSON.parse(localStorage.getItem('user'));
}

ngOnInit() {
  //this.listproperty = this._listpropertyService.getter();
  this._listpropertyService.getProperty(this.user.id).subscribe(
    (properties: any)=>{console.log(properties);
      this.properties=properties;
    },(error)=>{
      console.log(error);
    }
  )
  
  }
  
  //processForm(){
    //if(this.listproperty.id==undefined){
    //this._listpropertyService.listProperty(this.listproperty).subscribe((listproperty)=>{
    //console.log(listproperty);
    //this._router.navigate(['/listproperty']);
    //},(error)=>{
    //console.log(error);
    //});
    //}}
  
    //createProperty(){
      //this._listpropertyService.createProperty(this.user.id,this.listproperty).subscribe(data =>{console.log(
        //data
      //);
    //}, error=>{console.log(error)}
      //);
    //}
  
    //getProperty(id: string){
     // this.
    //}
  

}




