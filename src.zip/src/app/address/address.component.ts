import { Component, OnInit } from '@angular/core';
import {Customerdetails} from '../customerdetails';

@Component({
  selector: 'custaddress',
  templateUrl: './address.component.html',
  styleUrls: ['./address.component.scss']
})
export class AddressComponent implements OnInit {

private customerdetails: Customerdetails;

  constructor() { }

  ngOnInit() {
  }

}
