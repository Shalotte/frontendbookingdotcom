export class User {
    id: number;
    first_name: string;
    last_name: string;
    phone: string;
    email: string;
    password: string;
    type: string;
    
}
