import { Component, OnInit } from '@angular/core';
import {User} from '../user';

@Component({
  selector: 'app-booking',
  templateUrl: './booking.component.html',
  styleUrls: ['./booking.component.scss']
})
export class BookingComponent implements OnInit {
  user: User;

  constructor() {
    this.user = JSON.parse(localStorage.getItem('user'));
   }

  ngOnInit() {
  }

}
