export class Destination {

    id: number;
    province: string;
    city: string;
    check_in_date: Date;
    check_out_date: Date;
    rooms: number;
    adults: number;
    children: number;
    street_address: string;
    property_manager_name: string;
    property_manager_contact_details: string;


}
