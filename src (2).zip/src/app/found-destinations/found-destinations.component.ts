import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-found-destinations',
  templateUrl: './found-destinations.component.html',
  styleUrls: ['./found-destinations.component.scss']
})
export class FoundDestinationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
