import { Component, OnInit } from '@angular/core';
import {BsDatepickerConfig} from 'ngx-bootstrap/datepicker';
import {DestinationService} from '../shared_services/destination.service'
import {Destination} from '../destination';
import { first } from 'rxjs/operators';
import {User} from '../user';
import {Listproperty} from '../listproperty';
import {Router} from '@angular/router';

@Component({
  selector: 'app-customer-layout',
  templateUrl: './customer-layout.component.html',
  styleUrls: ['./customer-layout.component.scss']
})
export class CustomerLayoutComponent implements OnInit {
  datePickerConfig: Partial<BsDatepickerConfig>;
  myDateValue: Date;
  user: User;
  properties: Listproperty;
  private destination: Destination[];
  province: string;
  city: string;
  check_in_date: Date;
  check_out_date: Date;
  rooms: number;
  adults: number;
  children: number;
  listproperty: Listproperty;
  

  constructor(private destinationService:DestinationService, private router:Router) {
      this.user = JSON.parse(localStorage.getItem('user'));
      this.properties= JSON.parse(localStorage.getItem('properties'));
      this.datePickerConfig = Object.assign({},{containerClass: 'theme-dark-blue'});
  }

  
  ngOnInit() {
    this.myDateValue = new Date();
    this.province;
    this.city;
    this.check_in_date;
    this.check_out_date;
    this.rooms;
    this.adults;
    this.children;
    }

  onDateChange(newDate: Date) {
    console.log(newDate);
  }


  
    
    SearchDestination(){
    this.destinationService.searchDestination(this.province,this.city,this.check_in_date,this.check_out_date,
    this.rooms,this.adults,this.children).subscribe(destination => this.destination=destination);
    }
      
    onSubmit() {
    this.SearchDestination();
    }
    

}



