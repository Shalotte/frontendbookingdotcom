import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-custlayoutimages',
  templateUrl: './custlayoutimages.component.html',
  styleUrls: ['./custlayoutimages.component.scss']
})
export class CustlayoutimagesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
