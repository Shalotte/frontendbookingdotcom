import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listdestinations',
  templateUrl: './listdestinations.component.html',
  styleUrls: ['./listdestinations.component.scss']
})
export class ListdestinationsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
