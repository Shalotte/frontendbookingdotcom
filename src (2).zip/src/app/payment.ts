export class Payment {
    card_holder_name: string;
    card_type: string;
    card_number: string;
    expiry_date: string;
    cvc: string;
}
