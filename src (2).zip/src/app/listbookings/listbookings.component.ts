import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listbookings',
  templateUrl: './listbookings.component.html',
  styleUrls: ['./listbookings.component.scss']
})
export class ListbookingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
